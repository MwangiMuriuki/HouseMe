package com.example.houseme;

import android.app.Activity;
import android.os.Bundle;

public class ResetPassword extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
    }
}
